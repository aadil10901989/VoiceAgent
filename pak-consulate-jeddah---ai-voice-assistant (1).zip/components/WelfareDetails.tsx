
import React from 'react';
import { Language } from '../types';

interface WelfareDetailsProps {
  language: Language;
}

const WelfareDetails: React.FC<WelfareDetailsProps> = ({ language }) => {
  const isRtl = language === 'ar' || language === 'ur';

  const content = {
    en: [
      {
        title: "Labor Disputes",
        desc: "Seek help for unpaid wages or employer conflicts. Visit Wing 3 with your Iqama and Contract.",
        icon: "⚖️",
        color: "bg-blue-50 text-blue-600"
      },
      {
        title: "Legal Interpreters",
        desc: "Translators provided for court hearings. Submit a written request 3 days before your date.",
        icon: "🗣️",
        color: "bg-purple-50 text-purple-600"
      },
      {
        title: "Jail Visits",
        desc: "Regular visits to ensure rights of citizens. Relatives must provide inmate details to the wing.",
        icon: "🔒",
        color: "bg-red-50 text-red-600"
      },
      {
        title: "Burial Support",
        desc: "Coordination for local burial or repatriation of remains. 24/7 support available for NOCs.",
        icon: "🕊️",
        color: "bg-emerald-50 text-emerald-600"
      }
    ],
    ar: [
      {
        title: "نزاعات العمل",
        desc: "اطلب المساعدة في حال عدم دفع الرواتب أو الخلافات مع صاحب العمل. راجع الجناح ٣ مع الإقامة والعقد.",
        icon: "⚖️",
        color: "bg-blue-50 text-blue-600"
      },
      {
        title: "المترجمون القانونيون",
        desc: "توفير مترجمين لجلسات المحاكم. قدم طلباً خطياً قبل ٣ أيام من موعد الجلسة.",
        icon: "🗣️",
        color: "bg-purple-50 text-purple-600"
      },
      {
        title: "زيارات السجون",
        desc: "زيارات دورية لضمان حقوق المواطنين. يجب على الأقارب تقديم تفاصيل النزيل للجناح.",
        icon: "🔒",
        color: "bg-red-50 text-red-600"
      },
      {
        title: "دعم الدفن",
        desc: "التنسيق للدفن المحلي أو ترحيل الجثامين. دعم متاح على مدار الساعة لإصدار شهادات عدم الممانعة.",
        icon: "🕊️",
        color: "bg-emerald-50 text-emerald-600"
      }
    ],
    ur: [
      {
        title: "مزدور تنازعات",
        desc: "تنخواہوں کی عدم ادائیگی یا کفیل سے تنازعہ کی صورت میں مدد۔ اپنا اقامہ اور کنٹریکٹ لے کر ونگ 3 تشریف لائیں۔",
        icon: "⚖️",
        color: "bg-blue-50 text-blue-600"
      },
      {
        title: "قانونی مترجم",
        desc: "عدالتی سماعتوں کے لیے مترجم کی فراہمی۔ اپنی پیشی سے 3 دن قبل تحریری درخواست جمع کروائیں۔",
        icon: "🗣️",
        color: "bg-purple-50 text-purple-600"
      },
      {
        title: "جیل کے دورے",
        desc: "شہریوں کے حقوق کے تحفظ کے لیے باقاعدہ دورے۔ لواحقین کو قیدی کی تفصیلات فراہم کرنی ہوں گی۔",
        icon: "🔒",
        color: "bg-red-50 text-red-600"
      },
      {
        title: "تدفین کی معاونت",
        desc: "مقامی تدفین یا میت کی واپسی کے لیے کوآرڈینیشن۔ NOC کے لیے 24 گھنٹے مدد دستیاب ہے۔",
        icon: "🕊️",
        color: "bg-emerald-50 text-emerald-600"
      }
    ]
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {content[language].map((item, i) => (
        <div key={i} className="glass-card p-8 rounded-[3rem] flex items-start space-x-6 space-x-reverse hover:bg-white/95 group">
          <div className={`text-4xl ${item.color} p-5 rounded-[1.5rem] shadow-inner shrink-0 group-hover:scale-110 transition-transform`}>{item.icon}</div>
          <div>
            <h4 className="text-xl font-extrabold text-gray-900 mb-2 leading-tight">{item.title}</h4>
            <p className="text-gray-600 text-sm leading-relaxed font-medium">{item.desc}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default WelfareDetails;
