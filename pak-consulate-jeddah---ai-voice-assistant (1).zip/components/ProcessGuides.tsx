
import React from 'react';
import { UI_TEXT } from '../constants';
import { Language } from '../types';

interface ProcessGuidesProps {
  language: Language;
}

const ProcessGuides: React.FC<ProcessGuidesProps> = ({ language }) => {
  const t = UI_TEXT[language];
  const isRtl = language === 'ar' || language === 'ur';

  const guides = [
    {
      id: 'passport',
      title: { en: "Passport (New & Renewal)", ar: "الجوازات (جديد وتجديد)", ur: "پاسپورٹ (نیا اور تجدید)" },
      location: { en: "Passport Hall", ar: "صالة الجوازات", ur: "پاسپورٹ ہال" },
      steps: {
        en: [
          "Arrive early (8 AM - 12 PM) for same-day token",
          "Present original CNIC/NICOP at Reception for Token",
          "Complete Biometric Capture & Photo capture",
          "Verify personal data entry at assigned counter",
          "Pay the fee (155-550 SAR) at internal Bank counter"
        ],
        ar: [
          "الوصول مبكراً (٨ صباحاً - ١٢ ظهراً) للحصول على رقم",
          "تقديم الهوية الوطنية الأصلية في الاستقبال لاستلام الرقم",
          "إجراء البصمات الحيوية والتقاط الصورة الشخصية",
          "تدقيق البيانات الشخصية في كاونتر إدخال البيانات",
          "دفع الرسوم (١٥٥-٥٥٠ ريال) في كاونتر البنك الداخلي"
        ],
        ur: [
          "ٹوکن کے لیے صبح سویرے (8 سے 12 بجے) تشریف لائیں",
          "ریسپشن پر اصل شناختی کارڈ دکھا کر ٹوکن حاصل کریں",
          "بایومیٹرک اور تصویر کا مرحلہ مکمل کریں",
          "ڈیٹا انٹری کاؤنٹر پر اپنی معلومات کی تصدیق کریں",
          "قونصل خانہ کے بینک کاؤنٹر پر فیس جمع کروائیں"
        ]
      },
      reqs: { 
        en: "Original CNIC/NICOP (Mandatory), Iqama Copy, Old Passport", 
        ar: "بطاقة الهوية الأصلية (إلزامي)، صورة الإقامة، الجواز القديم", 
        ur: "اصل شناختی کارڈ (لازمی)، اقامہ کی کاپی، پرانا پاسپورٹ" 
      },
      color: "bg-green-700"
    },
    {
      id: 'nadra',
      title: { en: "NADRA (ID Card) Process", ar: "إجراءات نادرا", ur: "نادرا کا طریقہ کار" },
      location: { en: "NADRA Section", ar: "قسم نادرا", ur: "نادرا سیکشن" },
      steps: {
        en: ["Book appointment online (preferred)", "Visit NADRA Hall with identity docs", "Verification of family tree/records", "Capture live biometrics & signature", "Confirm delivery address for SNICOP"],
        ar: ["حجز موعد عبر الإنترنت (يفضل)", "زيارة صالة نادرا مع وثائق الهوية", "التحقق من سجلات العائلة", "التقاط البصمات الحيوية والتوقيع", "تأكيد عنوان استلام البطاقة الذكية"],
        ur: ["آن لائن اپائنٹمنٹ (بہتر ہے)", "شناختی دستاویزات کے ساتھ نادرا ہال آئیں", "فیملی ریکارڈ کی تصدیق", "بایومیٹرک اور دستخط کا اندراج", "کارڈ کی ترسیل کے پتے کی تصدیق"]
      },
      reqs: { en: "Old NICOP, Birth Cert, Parents' IDs", ar: "بطاقة الهوية القديمة، شهادة الميلاد", ur: "پرانا کارڈ، برتھ سرٹیفکیٹ، والدین کے شناختی کارڈ" },
      color: "bg-blue-800"
    },
    {
      id: 'visa',
      title: { en: "Visa Application Process", ar: "إجراءات التأشيرة", ur: "ویزا کا طریقہ کار" },
      location: { en: "Visa Counter / Online", ar: "كاونتر التأشيرات / أونلاين", ur: "ویزا کاؤنٹر / آن لائن" },
      steps: {
        en: ["Access Pakistan Online Visa Portal", "Upload Passport & Required Docs", "Pay processing fee online", "Await digital grant or interview call", "Check status via portal tracking"],
        ar: ["الدخول إلى بوابة التأشيرة الإلكترونية", "رفع الجواز والوثائق المطلوبة", "دفع رسوم المعالجة إلكترونياً", "انتظار الموافقة أو موعد المقابلة", "متابعة الحالة عبر البوابة"],
        ur: ["آن لائن ویزا پورٹل استعمال کریں", "پاسپورٹ اور دستاویزات اپ لوڈ کریں", "آن لائن فیس جمع کروائیں", "ای ویزا یا انٹرویو کال کا انتظار کریں", "پورٹل پر اسٹیٹس چیک کریں"]
      },
      reqs: { en: "Passport, Invitation, Proof of Stay", ar: "الجواز، دعوة، إثبات الإقامة", ur: "پاسپورٹ، دعوت نامہ، قیام کی تفصیلات" },
      color: "bg-indigo-700"
    },
    {
      id: 'attestation',
      title: { en: "Document Attestation", ar: "تصديق المستندات", ur: "دستاویزات کی تصدیق" },
      location: { en: "Attestation Section", ar: "قسم التصديقات", ur: "تصدیقات سیکشن" },
      steps: {
        en: [
          "Present original document & CNIC for verification",
          "Obtain payment slip from the counter",
          "Pay 40 SAR fee per document at the internal bank",
          "Submit document for official seal and signature",
          "Collect your attested document immediately"
        ],
        ar: [
          "تقديم المستند الأصلي والهوية للتحقق",
          "الحصول على قسيمة الدفع من الكاونتر",
          "دفع رسوم ٤٠ ريال لكل مستند في البنك الداخلي",
          "تقديم المستند للختم والتوقيع الرسمي",
          "استلام المستند المصدق فوراً"
        ],
        ur: [
          "تصدیق کے لیے اصل دستاویز اور شناختی کارڈ پیش کریں",
          "کاؤنٹر سے ادائیگی کی سلپ حاصل کریں",
          "اندرونی بینک میں 40 ریال فی دستاویز فیس جمع کریں",
          "سرکاری مہر اور دستخط کے لیے دستاویز جمع کروائیں",
          "تصدیق شدہ دستاویز فوری طور پر حاصل کریں"
        ]
      },
      reqs: { 
        en: "Original Doc, Applicant CNIC/Passport, Copy of Doc", 
        ar: "المستند الأصلي، هوية مقدم الطلب، صورة من المستند", 
        ur: "اصل دستاویز، درخواست گزار کا شناختی کارڈ، دستاویز کی فوٹو کاپی" 
      },
      color: "bg-teal-700"
    },
    {
      id: 'etd',
      title: { en: "Emergency Travel (ETD)", ar: "وثيقة السفر الطارئة (ETD)", ur: "ہنگامی سفری دستاویز (ETD)" },
      location: { en: "Passport / Welfare Wing", ar: "جناح الجوازات / الرفاهية", ur: "پاسپورٹ / ویلفیئر ونگ" },
      steps: {
        en: [
          "Report lost passport to Saudi Police & get formal report",
          "Visit Consulate with Police Report & 4 white-bg photos",
          "Provide copy of CNIC/NICOP for citizenship verification",
          "Pay the ETD processing fee (approx. 55 SAR)",
          "Collect the one-way document for travel to Pakistan"
        ],
        ar: [
          "بلاغ فقدان الجواز لدى الشرطة السعودية والحصول على تقرير",
          "زيارة القنصلية مع تقرير الشرطة و٤ صور بخلفية بيضاء",
          "تقديم نسخة من الهوية الوطنية للتحقق من المواطنة",
          "دفع رسوم معالجة الوثيقة (حوالي ٥٥ ريال)",
          "استلام وثيقة السفر لمرة واحدة للعودة إلى باكستان"
        ],
        ur: [
          "سعودی پولیس کو پاسپورٹ گمشدگی رپورٹ کریں اور رپورٹ لیں",
          "پولیس رپورٹ اور 4 تصاویر کے ساتھ قونصل خانہ آئیں",
          "شہریت کی تصدیق کے لیے شناختی کارڈ کی کاپی فراہم کریں",
          "ہنگامی دستاویز کی فیس (تقریباً 55 ریال) جمع کروائیں",
          "پاکستان واپسی کے لیے یکطرفہ سفری دستاویز حاصل کریں"
        ]
      },
      reqs: { 
        en: "Police Report, 4 Photos (White BG), ID Proof, ~55 SAR", 
        ar: "تقرير الشرطة، ٤ صور (خلفية بيضاء)، إثبات الهوية، ٥٥ ريال", 
        ur: "پولیس رپورٹ، 4 تصاویر، شناختی ثبوت، 55 ریال فیس" 
      },
      color: "bg-red-800"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {guides.map((guide) => (
          <div key={guide.id} className={`${guide.color} text-white rounded-[2.5rem] p-8 shadow-xl overflow-hidden relative group`}>
            <div className={`absolute top-0 ${isRtl ? 'left-0' : 'right-0'} p-8 opacity-10 group-hover:scale-110 transition-transform duration-500`}>
              <svg className="w-48 h-48" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zm0 14a6 6 0 110-12 6 6 0 010 12z"/></svg>
            </div>
            
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-2xl font-bold">{guide.title[language]}</h3>
                <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  {guide.location[language]}
                </span>
              </div>

              <ul className="space-y-4 mb-6">
                {guide.steps[language].map((step, i) => (
                  <li key={i} className="flex items-center space-x-4">
                    <span className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center font-bold shrink-0 text-sm">{i + 1}</span>
                    <span className="text-md opacity-90">{step}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-6 border-t border-white/20">
                <p className="text-xs font-bold uppercase tracking-widest opacity-60 mb-2">
                  {language === 'en' ? 'Core Requirements' : language === 'ar' ? 'المتطلبات الأساسية' : 'بنیادی ضروریات'}
                </p>
                <p className="text-sm font-medium">{guide.reqs[language]}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProcessGuides;
