
import React from 'react';
import { Language } from '../types';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

const Header: React.FC<HeaderProps> = ({ language, onLanguageChange }) => {
  return (
    <header className="py-8 flex flex-col md:flex-row items-center justify-between gap-6">
      <div className="flex items-center space-x-6 bg-white/10 backdrop-blur-md px-6 py-3 rounded-3xl border border-white/20 shadow-2xl">
        <div className="relative">
            <div className="absolute inset-0 bg-green-500 blur-md opacity-20 rounded-full"></div>
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/3/32/Flag_of_Pakistan.svg" 
              alt="Pakistan Flag" 
              className="h-12 w-auto rounded shadow-lg border border-white/40"
            />
        </div>
        <div className="text-white text-left">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400">Government of Pakistan</p>
          <p className="text-lg font-extrabold tracking-tight">Consulate General Jeddah</p>
        </div>
      </div>

      <div className="flex bg-black/20 backdrop-blur-lg p-1.5 rounded-2xl border border-white/10 shadow-inner">
        <button
          onClick={() => onLanguageChange('en')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all duration-300 ${
            language === 'en' ? 'bg-white text-green-950 shadow-xl scale-105' : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          English
        </button>
        <button
          onClick={() => onLanguageChange('ar')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all duration-300 arabic-font ${
            language === 'ar' ? 'bg-white text-green-950 shadow-xl scale-105' : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          العربية
        </button>
        <button
          onClick={() => onLanguageChange('ur')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all duration-300 urdu-font ${
            language === 'ur' ? 'bg-white text-green-950 shadow-xl scale-105' : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          اردو
        </button>
      </div>
    </header>
  );
};

export default Header;
