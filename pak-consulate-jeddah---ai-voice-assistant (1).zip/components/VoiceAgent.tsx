
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { decodeBase64, encodeBase64, decodeAudioData, float32ToInt16 } from '../services/audioUtils';
import { SYSTEM_INSTRUCTION, UI_TEXT, CONSULATE_COLORS } from '../constants';
import { Language, ConnectionStatus } from '../types';

interface VoiceAgentProps {
  language: Language;
}

const VoiceAgent: React.FC<VoiceAgentProps> = ({ language }) => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [sensitivity, setSensitivity] = useState(1.0); // Digital gain factor
  const [isNoisyEnv, setIsNoisyEnv] = useState(false); // Toggle noise suppression
  const [isWelcoming, setIsWelcoming] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const streamRef = useRef<MediaStream | null>(null);

  const t = UI_TEXT[language];
  const isRtl = language === 'ar' || language === 'ur';

  const stopAssistant = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current) audioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    
    setStatus(ConnectionStatus.DISCONNECTED);
    setIsSpeaking(false);
    setIsWelcoming(false);
  }, []);

  const startAssistant = async () => {
    try {
      setStatus(ConnectionStatus.CONNECTING);
      setIsWelcoming(true);
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: isNoisyEnv,
          autoGainControl: true
        }
      });
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: SYSTEM_INSTRUCTION,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          }
        },
        callbacks: {
          onopen: () => {
            setStatus(ConnectionStatus.CONNECTED);
            
            // Send a tiny bit of "empty" audio data immediately to trigger the system's proactive response
            sessionPromise.then(session => {
              // Creating a 0.1s silent PCM buffer
              const silentBuffer = new Int16Array(1600); 
              const base64Silent = encodeBase64(new Uint8Array(silentBuffer.buffer));
              session.sendRealtimeInput({
                media: { data: base64Silent, mimeType: 'audio/pcm;rate=16000' }
              });
            });

            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const boostedData = new Float32Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                boostedData[i] = inputData[i] * sensitivity;
              }

              const int16Data = float32ToInt16(boostedData);
              const base64Data = encodeBase64(new Uint8Array(int16Data.buffer));
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outputAudioContextRef.current) {
              setIsSpeaking(true);
              const decoded = decodeBase64(audioData);
              const buffer = await decodeAudioData(decoded, outputAudioContextRef.current, 24000, 1);
              
              const source = outputAudioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(outputAudioContextRef.current.destination);
              
              const now = outputAudioContextRef.current.currentTime;
              const start = Math.max(now, nextStartTimeRef.current);
              
              source.start(start);
              nextStartTimeRef.current = start + buffer.duration;
              sourcesRef.current.add(source);
              
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) {
                  setIsSpeaking(false);
                  setIsWelcoming(false); // Introduction complete
                }
              };
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsSpeaking(false);
              setIsWelcoming(false);
            }
          },
          onerror: (err) => {
            console.error('Gemini error:', err);
            setStatus(ConnectionStatus.ERROR);
            setIsWelcoming(false);
          },
          onclose: () => {
            setStatus(ConnectionStatus.DISCONNECTED);
            setIsWelcoming(false);
          }
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (error) {
      console.error('Failed to start assistant:', error);
      setStatus(ConnectionStatus.ERROR);
      setIsWelcoming(false);
    }
  };

  useEffect(() => {
    return () => stopAssistant();
  }, [stopAssistant]);

  return (
    <div className="bg-white rounded-[3rem] shadow-2xl p-8 md:p-10 border border-white/40 flex flex-col items-center max-w-2xl mx-auto backdrop-blur-md relative overflow-hidden">
      {/* Settings Toggle */}
      <button 
        onClick={() => setShowSettings(!showSettings)}
        className={`absolute top-8 ${isRtl ? 'left-8' : 'right-8'} p-3 rounded-2xl bg-gray-100 hover:bg-gray-200 transition-colors z-20`}
        title={t.settingsTitle}
      >
        <svg className={`w-5 h-5 text-gray-600 transition-transform duration-500 ${showSettings ? 'rotate-90' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      </button>

      {/* Settings Overlay */}
      {showSettings && (
        <div className="absolute inset-0 bg-white/95 backdrop-blur-xl z-10 flex flex-col p-10 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center justify-between mb-10">
            <h4 className="text-xl font-black text-green-950 tracking-tight">{t.settingsTitle}</h4>
            <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className="space-y-10">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-gray-900">{t.noisyEnv}</p>
                <p className="text-xs text-gray-500 mt-1">Enhance background noise filtering</p>
              </div>
              <button 
                onClick={() => setIsNoisyEnv(!isNoisyEnv)}
                className={`w-14 h-8 rounded-full transition-colors relative ${isNoisyEnv ? 'bg-green-600' : 'bg-gray-200'}`}
              >
                <div className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow-md transition-all ${isRtl ? (isNoisyEnv ? 'right-7' : 'right-1') : (isNoisyEnv ? 'left-7' : 'left-1')}`}></div>
              </button>
            </div>

            <div>
              <div className="flex justify-between items-end mb-4">
                <p className="font-bold text-gray-900">{t.sensitivity}</p>
                <span className="text-green-700 font-black text-sm">{sensitivity.toFixed(1)}x</span>
              </div>
              <div className="relative pt-1">
                <input 
                  type="range" 
                  min="0.5" 
                  max="3.0" 
                  step="0.1" 
                  value={sensitivity} 
                  onChange={(e) => setSensitivity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-green-600"
                />
                <div className="flex justify-between text-[10px] font-black uppercase text-gray-400 mt-2 tracking-widest">
                  <span>{t.low}</span>
                  <span>{t.high}</span>
                </div>
              </div>
            </div>
          </div>
          
          <p className="mt-auto text-center text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em] leading-relaxed">
            Note: Toggle noisy environment <br/> before starting the session.
          </p>
        </div>
      )}

      {/* Visual Status Indicator */}
      <div className="relative mb-8 md:mb-10">
        <div className={`w-32 h-32 md:w-40 md:h-40 rounded-full flex items-center justify-center transition-all duration-700 ${
          status === ConnectionStatus.CONNECTED ? 'bg-green-100/50 scale-110' : 'bg-gray-50'
        }`}>
          {status === ConnectionStatus.CONNECTED && (
            <>
              <div className="absolute inset-0 rounded-full border-2 border-green-500 animate-[ping_2s_infinite] opacity-20"></div>
              <div className="absolute inset-[-10px] rounded-full border border-green-400 animate-[ping_3s_infinite] opacity-10"></div>
            </>
          )}
          
          <div className={`relative z-10 p-6 md:p-8 rounded-full transition-colors duration-500 ${status === ConnectionStatus.CONNECTED ? 'bg-green-600 shadow-xl shadow-green-200' : 'bg-gray-200'}`}>
            <svg className={`w-10 h-10 md:w-12 md:h-12 ${status === ConnectionStatus.CONNECTED ? 'text-white' : 'text-gray-500'}`} fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
            </svg>
          </div>
        </div>
      </div>

      {/* Voice Prompt Text */}
      <div className="text-center mb-10">
        <h3 className="text-xl md:text-2xl font-black text-green-950 mb-3 tracking-tight">
          {status === ConnectionStatus.CONNECTED ? (isWelcoming ? 'Assistant Introduction' : t.statusConnected) : 
           status === ConnectionStatus.CONNECTING ? t.statusConnecting : t.statusDisconnected}
        </h3>
        <p className="text-gray-600 text-sm md:text-base font-bold max-w-sm mx-auto leading-relaxed h-12">
          {isWelcoming ? (
            language === 'en' ? 'Welcome to Pakistan Consulate General...' : 
            language === 'ar' ? 'مرحبًا بكم في القنصلية العامة...' : 'پاکستان قونصل خانے میں خوش آمدید...'
          ) : (
            language === 'en' ? 'How can I help you? Just press the button to start.' : 
            language === 'ar' ? 'كيف يمكنني مساعدتك؟ فقط اضغط على الزر للبدء.' : 'میں آپ کی کیا مدد کر سکتا ہوں؟ بس بٹن دبائیں۔'
          )}
        </p>
      </div>

      {/* Main Interaction Button */}
      <button
        onClick={status === ConnectionStatus.CONNECTED ? stopAssistant : startAssistant}
        className={`w-full py-5 md:py-6 rounded-2xl font-black text-lg md:text-xl transition-all duration-500 flex items-center justify-center space-x-4 uppercase tracking-widest ${
          status === ConnectionStatus.CONNECTED 
          ? 'bg-red-50 text-red-600 hover:bg-red-100 border-2 border-red-200 shadow-inner' 
          : 'bg-green-700 text-white hover:bg-green-800 shadow-2xl shadow-green-900/20 hover:-translate-y-1'
        }`}
      >
        <span className={`shrink-0 ${isRtl ? 'ml-4' : 'mr-4'}`}>
          {status === ConnectionStatus.CONNECTED ? (
             <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd"/></svg>
          ) : (
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd"/></svg>
          )}
        </span>
        <span>{status === ConnectionStatus.CONNECTED ? t.stopAssistant : t.startAssistant}</span>
      </button>

      {/* Voice Animation */}
      <div className={`mt-10 flex items-center space-x-2 transition-opacity duration-500 ${status === ConnectionStatus.CONNECTED ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex space-x-1.5 h-6 items-center">
          {[...Array(8)].map((_, i) => (
            <div 
              key={i} 
              className={`w-1.5 bg-green-500 rounded-full transition-all duration-300 ${
                isSpeaking 
                  ? 'animate-[bounce_0.6s_infinite] h-6' 
                  : 'h-2 opacity-30'
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            ></div>
          ))}
        </div>
        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-green-600/60 ml-4">
          {isSpeaking ? (isWelcoming ? 'Introduction' : 'AI Processing') : 'Listening...'}
        </span>
      </div>
    </div>
  );
};

export default VoiceAgent;
